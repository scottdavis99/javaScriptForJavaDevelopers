var name = "Scott"

var hello = function(){
	console.log("Hi " + name);
	var name = "Venkat"
  console.log("Hi " + name);
}

hello()
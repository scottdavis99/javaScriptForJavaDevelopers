public class PersonTest{
  public static void main(String[] args) {
    Person p = new Person("Scott", "Broomfield");
    System.out.println(p);
  }
}